﻿UL Safety IndexTM Data File
This tab-delimited file provides the data for the UL Safety Index, an algorithm based data science initiative that provides individuals and organizations relevant data they may use to explore safety, inform policy and investment choices and make science-based decisions for a more secure, healthier and safer world.  

The file contains indicators, drivers and index values for 187 countries.  The data include the input data as well as the normalized indicators.  For more information about the normalization process and the calculation of the indicators, drivers and index, go to http://www.ulsafetyindex.org.  
Data fields that end in “rating” are the indicators within the index and range from 0 to 100.

The following .csv data sets are included in the download:  
UL_safety_index_data_2000.csv
UL_safety_index_data_2005.csv
UL_safety_index_data_2010.csv
UL_safety_index_data_2016.csv
UL_safety_index_data_2017.csv


This UL Safety Index data is made available under the Open Database License: http://opendatacommons.org/licenses/odbl/1.0/. Any rights in individual contents of the database are licensed under the Database Contents License: http://opendatacommons.org/licenses/dbcl/1.0/

Data Definitions
Field Name
Field 
Type
Units
Definition

Country Data
country_slug
Text
N/A
Name of country used to match country to standard names in mapping software.

country
Text
N/A
Name of country based on United Nations country list.

Index and Drivers Data
ul_safety_index	
Number
N/A
UL Safety Index.  Range:  0-100

institutions_resources
Number
N/A
Institutions & Resources Driver.  Range:  0-100.

safety_frameworks
Number
N/A
Safety Frameworks Driver.  Range:  0-100

safety_outcomes
Number
N/A
Safety Outcomes Driver.  Range: 0-100

Raw Data and Indicators
transport_injuries
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from transport injuries in a country divided by the population of the country in 100K persons.

transport_injuries_rating
Number
N/A
Transport injuries Indicator.  Calculated by normalizing “transport_injuries” using the min-max method.  Range:  0-100.

falls
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from fall injuries in a country divided by the population of the country.

falls_rating
Number
N/A
Fall injuries Indicator.  Calculated by normalizing “falls” using the min-max method.  Range:  0-100.

drowning
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from drowning injuries in a country divided by the population of the country.

drowning_rating
Number
N/A
Drowning injuries Indicator.  Calculated by normalizing “drowing” using the min-max method.  Range:  0-100.

fires_heat_hot_substances
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from injuries due to fires, heat and hot substances in a country divided by the population of the country.

fires_heat_hot_substances_rating
Number
N/A
Fires, Heat and Hot Substances injuries Indicator.  Calculated by normalizing “fires_heat_hot_substances” using the min-max method.  Range:  0-100.

poisonings
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from poisoning injuries in a country divided by the population of the country.

poisonings_rating
Number
N/A
Poisoning injuries Indicator.  Calculated by normalizing “poisonings” using the min-max method.  Range:  0-100.

exposure_to_mechanical_forces
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from injuries due to exposure to mechanical forces, such as crushing, pinching, etc. in a country divided by the population of the country.

exposure_to_mechanical_forces_rating
Number
N/A
Exposure to Mechanical Forces injuries Indicator.  Calculated by normalizing “exposure-to-mechanical-forces” using the min-max method.  Range:  0-100.

foreign_body
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from injuries due to foreign bodies, such as choking, in a country divided by the population of the country.

foreign_body_rating
Number
N/A
Foreign Body injuries Indicator.  Calculated by normalizing “foreign_body” using the min-max method.  Range:  0-100.

other_unintentional_injuries
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from unintentional injuries not covered by other categories in a country divided by the population of the country.

other_unintentional_injuries_rating
Number
N/A
Other Unintentional Injuries Indicator.  Calculated by normalizing “other_unintentional_injuries” using the min-max method.  Range:  0-100.

exposure_to_forces_of_nature_disaster
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from injuries caused by exposure to the forces of nature and natural disaster, such as earthquakes, in a country divided by the population of the country.

exposure_to_forces_of_nature_disaster_rating
Number
N/A
Exposure to Forces of Nature, Disaster injuries Indicator.  Calculated by normalizing “exposure_to_forces_of_nature_disaster” using the min-max method.  Range:  0-100.

unintentional_injuries
Number
DALY/100,000 Population
The number of years of life lived in disability or years lost due to premature death from injuries caused by all categories of unintentional injury.

gdp_per_capita
Number
USD per capita
Gross Domestic Product per capita from The World Bank.  

gdp_per_capita_rating	
Number
N/A
GDP per Capita Indicator.  Calculated by normalizing “gdp_per_capita” using the min-max method.  Range:  0-100.

government_effectiveness
Number
N/A
The Government Effectiveness Index from the World Bank.

government_effectiveness_rating
Number
N/A
Government Effectiveness Indicator.  Calculated by normalizing “government_effectiveness” using the min-max method.  Range:  0-100.

education
Number
N/A
The Education Index from the UN Development Programme.

education_rating
Number
N/A
Education Indicator.  Calculated by normalizing “education” using the min-max method.  Range:  0-100.

technology (2017) network_readiness (2000, 2005, 2010, 2016)
Number
N/A
Technology Index based on the Networked Readiness Index from the Worldwide Economic Forum.  Prior to 2017, this was the NRI from the WEF with no modifications.

technology_rating (2017) network_readiness_rating (2000, 2005, 2010, 2016)
Number
N/A
Tehcnology or Networked Readiness Index Indicator.  Calculated by normalizing "technology" or “network_readiness” using the min-max method.  Range:  0-100.

ul_standards_index
Number
N/A
The UL Standards Index, calculated by scoring countries for participation in international standards activities.  Range:  0-15

ul_standards_index_rating
Number
N/A
Standards Index Indicator.  Calculated by normalizing "ul_standards_index" using the min-max method.  Range:  0-100.

consumer_protection_survey
Number
N/A
A score for consumer protection measures, calculated from the results of the Consumers’ International Consumer Protection Survey.  

consumer_protection_survey_rating
Number
N/A
Consumer Protections Indicator.  Calculated by normalizing “consumer_protection_survey” using the min-max method. Range:  0-100.

ul_labor_rights
Number
N/A
The UL Labor Rights Index, calculated from a country’s record in protecting laborer’s rights.  Range:  0-100

ul_labor_rights_index_rating
Number
N/A
Labor Protections Indicator.  Calculated by normalizing “ul_labor_rights” using the min-max method.  Range:  0-100.

road_safety
Number
N/A
A score for the number and type of road safety regulations, standards and metrics adopted by each country, from the 2015 Global Status Report on Road Safety by the World Health Organization.

road_safety_rating
Number
N/A
Road Safety Frameworks indicator.  Calculated by normalizing “road_safety” using the min-max method.  Range:  0-100.

Rankings
ul_safety_index_rank
Number
N/A
Country rank based on UL Safety Index.  Range:  1-187

institutions_resources_rank
Number
N/A
Country rank based on the Institutions & Resources driver.  Range:  1-187

safety_frameworks_rank
Number
N/A
Country rank based on the Safety Frameworks driver.  Range:  1-187

safety_outcomes_rank
Number
N/A
Country rank based on the Safety Outcomes driver.  Range:  1-187

transport_injuries_rating_rank
Number
N/A
Country rank based on the Transport Injuries indicator.  Range:  1-187

falls_rating_rank
Number
N/A
Country rank based on the Falls Injuries indicator.  Range:  1-187

drowning_rating_rank
Number
N/A
Country rank based on the Drowning Injuries indicator.  Range:  1-187

fires_heat_hot_substances_rating_rank
Number
N/A
Country rank based on the Fires, heat and hot substances injuries indicator.  Range:  1-187

poisonings_rating_rank
Number
N/A
Country rank based on the Poisoning Injuries indicator.  Range:  1-187

exposure_to_mechanical_forces_rating_rank
Number
N/A
Country rank based on the Exposure to mechanical forces injuries indicator.  Range:  1-187

foreign_body_rating_rank
Number
N/A
Country rank based on Foreign body injuries indicator.  Range:  1-187

other_unintentional_injuries_rating_rank
Number
N/A
Country rank based on the Other unintentional injuries indicator.  Range:  1-187

exposure_to_forces_of_nature_disaster_rating_rank
Number
N/A
Country rank based on the Exposure to forces of nature & disaster injuries indicator.  Range:  1-187

gdp_per_capita_rating_rank
Number
N/A
Country rank based on the GDP per capita indicator.  Range:  1-187

government_effectiveness_rating_rank
Number
N/A
Country rank based on Government Effectiveness indicator.  Range:  1-187

education_rating_rank
Number
N/A
Country rank based on the Education indicator.  Range:  1-187

technology or network_readiness_rating_rank
Number
N/A
Country rank based on the Technology or Networked Readiness Index indicator.  Range:  1-187

ul_standards_index_rating_rank
Number
N/A
Country rank based on the codes & standards indicator.  Range:  1-187

consumer_protection_survey_rating_rank
Number
N/A
Country rank based on Consumer Protection indicator.  Range:  1-187

ul_labor_rights_index_rating_rank
Number
N/A
Country rank based on the Labor Rights Indicator.  Range:  1-187

road_safety_rating_rank
Number
N/A
Country rank based on the Road Safety Frameworks indicator.  Range:  1-187

Peer Group Information
population
Number
persons
Country population.  

population_decile
Number
N/A
Each of ten equal groups into which the countries have been divided, based on population.  Decile = 1 corresponds to the top 10% of countries in the world, based on population.  Range:  1-10

population_under_15
Number
N/A
Proportion of youth population of the country, aged 15 and under, based on Population Reference Bureau data.

youth_population_group
Number
N/A
Grouping of countries with similar youth population percentages.

population_over_65
Number
N/A
Proportion of elderly population of the country, aged 65 and over, based on Population Reference Bureau data.

older_population_group
Number
N/A
Grouping of countries with similar elder population percentages.

gdp
Number
US Dollars
Gross Domestic Product for the country. 

gdp_decile
Number
N/A
Each of ten equal groups into which the countries have been divided based on GDP.  Decile = 1 corresponds to the top 10% of countries in the world, based on GDP.  Range:  1-10

oecd
text
Y/N
Is the country a member of the Organization for Economic Cooperation and Development (OECD)?

g7
text
Y/N
Is the country a member of the Group of Seven (G7)?

g20
text
Y/N
Is the country a member of the Group of Twenty (G20)? 

un_region
Text
N/A
Region of the world based on United Nations classifications.

un_sub_region
Text
N/A
Sub-region of the world based on United Nations classifications.

un_development_status	
Text
N/A
Development status based on United Nations classifications .

who_region
Text
N/A
Region of the world based on World Health Organization classification.

iso_abbreviation
Text
N/A
The abbreviation for the country name, based on the International Standards Organization.

iso_membership
Text
N/A
Membership classification within the International Standards Organization

iec_membership
Text
N/A
Membership classification within the International Electrotechnical Commission












